# Weather-Forecast-and-Disaster-Alram-in-Hilly-Areas
I Developed this Weather Forecast And Disaster Alarm In Hilly Areas Console Application in which User will first enter the name of the city and in result we will show complete weather forecast along with the note that wheather place is travel to SAFE or not.
